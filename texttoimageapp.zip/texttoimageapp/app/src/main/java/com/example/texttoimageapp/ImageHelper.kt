package com.example.texttoimageapp

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.Log
import android.widget.ImageView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.target.Target
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Helper class to handle image loading functionality
 */
class ImageHelper(private val context: Context) {

    private val TAG = "ImageHelper"
    // Pexels API key
    private val PEXELS_API_KEY = "ndH0bv4i1OTlmJ3i3QAK3E2MvYsHexRAILQa5pBqUf3Ipg9ZkQ6LSaNZ"

    /**
     * Loads an image into the provided ImageView based on the search query
     */
    fun loadImageFromQuery(
        query: String,
        imageView: ImageView,
        onStart: () -> Unit = {},
        onSuccess: () -> Unit = {},
        onError: (Exception) -> Unit = {}
    ) {
        try {
            onStart()

            if (query.isBlank()) {
                throw IllegalArgumentException("Search query cannot be empty")
            }

            // Create Pexels API request
            val encodedQuery = URLEncoder.encode(query.trim(), StandardCharsets.UTF_8.toString())
            val apiUrl = "https://api.pexels.com/v1/search?query=$encodedQuery&per_page=1"

            val jsonObjectRequest = object : JsonObjectRequest(
                Request.Method.GET, apiUrl, null,
                { response ->
                    try {
                        val photos = response.getJSONArray("photos")
                        if (photos.length() > 0) {
                            val photo = photos.getJSONObject(0)
                            val imageUrl = photo.getJSONObject("src").getString("large")
                            loadImageWithGlide(imageUrl, imageView, onSuccess, onError)
                        } else {
                            onError(Exception("No images found for: $query"))
                        }
                    } catch (e: Exception) {
                        onError(e)
                    }
                },
                { error ->
                    Log.e(TAG, "Error: ${error.message}", error)
                    onError(Exception("Network error: ${error.message}"))
                }
            ) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Authorization"] = PEXELS_API_KEY
                    return headers
                }
            }

            // Add request to queue
            Volley.newRequestQueue(context).add(jsonObjectRequest)

        } catch (e: Exception) {
            Log.e(TAG, "Error in loadImageFromQuery: ${e.message}", e)
            onError(e)
        }
    }

    private fun loadImageWithGlide(
        imageUrl: String,
        imageView: ImageView,
        onSuccess: () -> Unit,
        onError: (Exception) -> Unit
    ) {
        val requestOptions = RequestOptions()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .placeholder(R.drawable.placeholder_image)
            .error(R.drawable.error_image)

        Glide.with(context.applicationContext)
            .load(imageUrl)
            .apply(requestOptions)
            .transition(DrawableTransitionOptions.withCrossFade())
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    val errorMessage = e?.rootCauses?.firstOrNull()?.message ?: "Unknown error"
                    Log.e(TAG, "Error loading image: $errorMessage", e)
                    onError(Exception("Failed to load image. Please check your internet connection and try again."))
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable,
                    model: Any,
                    target: Target<Drawable>,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean {
                    Log.d(TAG, "Image loaded successfully from $dataSource")
                    onSuccess()
                    return false
                }
            })
            .into(imageView)
    }
} 