package com.example.texttoimageapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var imageView: ImageView
    private lateinit var searchButton: Button
    private lateinit var voiceButton: Button
    private lateinit var resultTextView: TextView
    private lateinit var imageHelper: ImageHelper

    private val REQUEST_CODE_SPEECH_INPUT = 100
    private val RECORD_AUDIO_PERMISSION_CODE = 101
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            setContentView(R.layout.activity_main)
            initializeViews()
            setupClickListeners()
            imageHelper = ImageHelper(this)
        } catch (e: Exception) {
            Log.e(TAG, "Error in onCreate: ${e.message}", e)
            Toast.makeText(this, "Error initializing app: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun initializeViews() {
        try {
            editText = findViewById(R.id.editText)
            imageView = findViewById(R.id.imageView)
            searchButton = findViewById(R.id.searchButton)
            voiceButton = findViewById(R.id.voiceButton)
            resultTextView = findViewById(R.id.resultTextView)
            resultTextView.text = "Enter text or use voice input"
        } catch (e: Exception) {
            throw RuntimeException("Error initializing views: ${e.message}")
        }
    }

    private fun setupClickListeners() {
        searchButton.setOnClickListener {
            try {
                val searchText = editText.text.toString().trim()
                if (searchText.isNotEmpty()) {
                    loadImage(searchText)
                } else {
                    Toast.makeText(this, "Please enter text", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in search button click: ${e.message}", e)
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        voiceButton.setOnClickListener {
            askSpeechInputPermission()
        }
    }

    private fun askSpeechInputPermission() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> {
                startSpeechToText()
            }
            ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO) -> {
                Toast.makeText(this, "Microphone permission is required for voice input", Toast.LENGTH_LONG).show()
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.RECORD_AUDIO),
                    RECORD_AUDIO_PERMISSION_CODE
                )
            }
            else -> {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.RECORD_AUDIO),
                    RECORD_AUDIO_PERMISSION_CODE
                )
            }
        }
    }

    private fun startSpeechToText() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak something to search for an image")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
            }
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting speech recognition: ${e.message}", e)
            Toast.makeText(
                this,
                "Speech recognition error: Please check if Google app is installed and microphone permissions are granted",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            RECORD_AUDIO_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startSpeechToText()
                } else {
                    Toast.makeText(this, "Permission denied for voice input", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            when (resultCode) {
                RESULT_OK -> {
                    try {
                        val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                        if (!result.isNullOrEmpty()) {
                            val spokenText = result[0]
                            editText.setText(spokenText)
                            if (spokenText.isNotEmpty()) {
                                loadImage(spokenText)
                            }
                        } else {
                            Toast.makeText(this, "Could not understand speech. Please try again.", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error processing speech result: ${e.message}", e)
                        Toast.makeText(this, "Error processing speech. Please try again.", Toast.LENGTH_SHORT).show()
                    }
                }
                RESULT_CANCELED -> {
                    Toast.makeText(this, "Speech input cancelled. Please try again.", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    Toast.makeText(this, "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadImage(searchQuery: String) {
        try {
            resultTextView.text = "Loading image for: $searchQuery"
            searchButton.isEnabled = false
            voiceButton.isEnabled = false
            
            imageHelper.loadImageFromQuery(
                query = searchQuery,
                imageView = imageView,
                onStart = {
                    resultTextView.text = "Searching for images of: $searchQuery..."
                    imageView.setImageResource(R.drawable.placeholder_image)
                },
                onSuccess = {
                    resultTextView.text = "Found image for: $searchQuery"
                    searchButton.isEnabled = true
                    voiceButton.isEnabled = true
                },
                onError = { e ->
                    val errorMessage = e.message ?: "Unknown error occurred"
                    Log.e(TAG, "Error loading image: $errorMessage", e)
                    resultTextView.text = "Couldn't find image. Please try another search term."
                    imageView.setImageResource(R.drawable.error_image)
                    Toast.makeText(this, "Error: $errorMessage", Toast.LENGTH_SHORT).show()
                    searchButton.isEnabled = true
                    voiceButton.isEnabled = true
                }
            )
        } catch (e: Exception) {
            val errorMessage = e.message ?: "Unknown error occurred"
            Log.e(TAG, "Error in loadImage: $errorMessage", e)
            resultTextView.text = "Error: $errorMessage"
            imageView.setImageResource(R.drawable.error_image)
            Toast.makeText(this, "Error: $errorMessage", Toast.LENGTH_SHORT).show()
            searchButton.isEnabled = true
            voiceButton.isEnabled = true
        }
    }
}