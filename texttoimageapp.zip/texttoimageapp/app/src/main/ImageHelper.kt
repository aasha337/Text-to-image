package com.example.texttoimageapp

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.Log
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.transition.DrawableCrossFadeFactory
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.concurrent.thread

/**
 * Helper class to handle image loading functionality
 */
class ImageHelper(private val context: Context) {

    private val TAG = "ImageHelper"
    private val PIXABAY_API_KEY = "YOUR_PIXABAY_API_KEY" // Replace with your Pixabay API key
    private val crossFadeFactory = DrawableCrossFadeFactory.Builder().setCrossFadeEnabled(true).build()

    /**
     * Loads an image into the provided ImageView based on the search query
     */
    fun loadImageFromQuery(
        query: String,
        imageView: ImageView,
        onStart: () -> Unit = {},
        onSuccess: () -> Unit = {},
        onError: (Exception) -> Unit = {}
    ) {
        try {
            onStart()

            if (query.isBlank()) {
                throw IllegalArgumentException("Search query cannot be empty")
            }

            // Start a background thread for the network request
            thread {
                try {
                    // Properly encode the query for URL
                    val encodedQuery = URLEncoder.encode(query.trim(), StandardCharsets.UTF_8.toString())

                    // Create Pixabay API URL
                    val apiUrl = "https://pixabay.com/api/?key=$PIXABAY_API_KEY&q=$encodedQuery&image_type=photo&per_page=3"

                    // Make the API request
                    val response = URL(apiUrl).readText()
                    val jsonResponse = JSONObject(response)
                    val hits = jsonResponse.getJSONArray("hits")

                    if (hits.length() > 0) {
                        // Get the first image URL
                        val imageUrl = hits.getJSONObject(0).getString("webformatURL")

                        // Switch back to main thread for UI updates
                        context.mainExecutor.execute {
                            loadImageWithGlide(imageUrl, imageView, onSuccess, onError)
                        }
                    } else {
                        context.mainExecutor.execute {
                            onError(Exception("No images found for: $query"))
                        }
                    }
                } catch (e: Exception) {
                    context.mainExecutor.execute {
                        onError(e)
                    }
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error in loadImageFromQuery: ${e.message}", e)
            onError(e)
        }
    }

    private fun loadImageWithGlide(
        imageUrl: String,
        imageView: ImageView,
        onSuccess: () -> Unit,
        onError: (Exception) -> Unit
    ) {
        // Configure Glide with error handling
        val requestOptions = RequestOptions()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .placeholder(R.drawable.placeholder_image)
            .error(R.drawable.error_image)

        // Load the image with a smooth transition
        Glide.with(context.applicationContext)
            .load(imageUrl)
            .apply(requestOptions)
            .transition(DrawableTransitionOptions.withCrossFade(crossFadeFactory))
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    val errorMessage = e?.rootCauses?.firstOrNull()?.message ?: "Unknown error"
                    Log.e(TAG, "Error loading image: $errorMessage", e)
                    onError(Exception("Failed to load image: $errorMessage"))
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable,
                    model: Any,
                    target: Target<Drawable>,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean {
                    Log.d(TAG, "Image loaded successfully from $dataSource")
                    onSuccess()
                    return false
                }
            })
            .into(imageView)
    }
}